public class Student {
    public String name = "default name";
    public int index = 0;



}
